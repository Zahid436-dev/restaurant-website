// Variables globales
let currentChart = null;
let categoriesList = [];

// Initialisation
document.addEventListener('DOMContentLoaded', function() {
    updateDateTime();
    setInterval(updateDateTime, 1000);
    loadDashboardStats();
    loadTodayReservations();
    loadCategories();
    setupNavigation();
});

// Navigation
function setupNavigation() {
    const navItems = document.querySelectorAll('.nav-item');
    const pages = document.querySelectorAll('.page');
    
    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const pageId = item.dataset.page;
            
            navItems.forEach(nav => nav.classList.remove('active'));
            item.classList.add('active');
            
            pages.forEach(page => page.classList.remove('active'));
            document.getElementById(`${pageId}-page`).classList.add('active');
            
            // Charger les données selon la page
            if (pageId === 'reservations') loadReservations();
            if (pageId === 'menu') loadMenuForManagement();
            if (pageId === 'messages') loadMessages();
            if (pageId === 'stats') loadStatistics();
        });
    });
}

// Mise à jour date/heure
function updateDateTime() {
    const now = new Date();
    const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' };
    const dateTimeElement = document.getElementById('current-datetime');
    if (dateTimeElement) {
        dateTimeElement.textContent = now.toLocaleDateString('fr-FR', options);
    }
}

// Charger les statistiques du dashboard
async function loadDashboardStats() {
    try {
        const response = await fetch('php/get_stats.php');
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('stat-today').textContent = data.data.reservations_today || 0;
            document.getElementById('stat-pending').textContent = data.data.reservations_pending || 0;
            document.getElementById('stat-messages').textContent = data.data.unread_messages || 0;
            document.getElementById('stat-occupancy').textContent = data.data.occupancy_rate + '%' || '0%';
            document.getElementById('stat-menu').textContent = data.data.menu_items || 0;
            document.getElementById('stat-revenue').textContent = (data.data.estimated_revenue || 0) + ' €';
            
            document.getElementById('pending-badge').textContent = data.data.reservations_pending || 0;
            document.getElementById('messages-badge').textContent = data.data.unread_messages || 0;
        }
    } catch (error) {
        console.error('Erreur:', error);
    }
}

// Charger les réservations du jour
async function loadTodayReservations() {
    const container = document.getElementById('today-reservations');
    if (!container) return;
    
    try {
        const today = new Date().toISOString().split('T')[0];
        const response = await fetch(`php/get_reservations.php?date=${today}`);
        const data = await response.json();
        
        if (data.success && data.data.length > 0) {
            let html = `
                <table>
                    <thead>
                        <tr>
                            <th>Heure</th>
                            <th>Nom</th>
                            <th>Personnes</th>
                            <th>Téléphone</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            data.data.forEach(res => {
                html += `
                    <tr>
                        <td>${res.time}</td>
                        <td>${escapeHtml(res.name)}</td>
                        <td>${res.guests}</td>
                        <td>${res.phone || '-'}</td>
                        <td><span class="status-badge status-${res.status}">${getStatusText(res.status)}</span></td>
                        <td>
                            <select onchange="updateReservationStatus(${res.id}, this.value)" class="status-select">
                                <option value="pending" ${res.status === 'pending' ? 'selected' : ''}>En attente</option>
                                <option value="confirmed" ${res.status === 'confirmed' ? 'selected' : ''}>Confirmée</option>
                                <option value="completed" ${res.status === 'completed' ? 'selected' : ''}>Terminée</option>
                                <option value="cancelled" ${res.status === 'cancelled' ? 'selected' : ''}>Annulée</option>
                            </select>
                            <button onclick="deleteReservation(${res.id})" class="btn-delete-reservation">
                                <i class="fas fa-trash"></i> Supprimer
                            </button>
                        </td>
                    </tr>
                `;
            });
            
            html += '</tbody></table>';
            container.innerHTML = html;
        } else {
            container.innerHTML = '<div class="loading">Aucune réservation pour aujourd\'hui</div>';
        }
    } catch (error) {
        container.innerHTML = '<div class="loading">Erreur de chargement</div>';
    }
}

// Charger toutes les réservations
async function loadReservations() {
    const container = document.getElementById('reservations-list');
    if (!container) return;
    
    const date = document.getElementById('filter-date')?.value || new Date().toISOString().split('T')[0];
    const status = document.getElementById('filter-status')?.value || 'all';
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Chargement...</div>';
    
    try {
        const response = await fetch(`php/get_reservations.php?date=${date}&status=${status}`);
        const data = await response.json();
        
        if (data.success) {
            if (data.data.length > 0) {
                let html = `
                    <table>
                        <thead>
                            <tr>
                                <th>Heure</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Téléphone</th>
                                <th>Personnes</th>
                                <th>Statut</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                `;
                
                data.data.forEach(res => {
                    html += `
                        <tr>
                            <td>${res.time}</td>
                            <td>${escapeHtml(res.name)}</td>
                            <td>${escapeHtml(res.email)}</td>
                            <td>${res.phone || '-'}</td>
                            <td>${res.guests}</td>
                            <td><span class="status-badge status-${res.status}">${getStatusText(res.status)}</span></td>
                            <td>
                                <select onchange="updateReservationStatus(${res.id}, this.value)" class="status-select">
                                    <option value="pending" ${res.status === 'pending' ? 'selected' : ''}>En attente</option>
                                    <option value="confirmed" ${res.status === 'confirmed' ? 'selected' : ''}>Confirmée</option>
                                    <option value="completed" ${res.status === 'completed' ? 'selected' : ''}>Terminée</option>
                                    <option value="cancelled" ${res.status === 'cancelled' ? 'selected' : ''}>Annulée</option>
                                </select>
                                <button onclick="deleteReservation(${res.id})" class="btn-delete-reservation">
                                    <i class="fas fa-trash"></i> Supprimer
                                </button>
                            </td>
                        </tr>
                    `;
                });
                
                html += '</tbody></table>';
                container.innerHTML = html;
            } else {
                container.innerHTML = '<div class="loading">Aucune réservation trouvée</div>';
            }
        }
    } catch (error) {
        container.innerHTML = '<div class="loading">Erreur de chargement</div>';
    }
}

// Supprimer une réservation
async function deleteReservation(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette réservation ? Cette action est irréversible.')) {
        try {
            const response = await fetch('php/delete_reservation.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id: id })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification('Réservation supprimée avec succès', 'success');
                // Recharger les listes
                loadTodayReservations();
                loadReservations();
                loadDashboardStats();
            } else {
                showNotification(data.message || 'Erreur lors de la suppression', 'error');
            }
        } catch (error) {
            console.error('Erreur:', error);
            showNotification('Erreur de connexion au serveur', 'error');
        }
    }
}

// Mettre à jour le statut d'une réservation
async function updateReservationStatus(id, status) {
    try {
        const response = await fetch('php/update_reservation.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id, status })
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadTodayReservations();
            loadReservations();
            loadDashboardStats();
            showNotification('Statut mis à jour', 'success');
        } else {
            showNotification('Erreur lors de la mise à jour', 'error');
        }
    } catch (error) {
        showNotification('Erreur de connexion', 'error');
    }
}

// Charger les catégories
async function loadCategories() {
    try {
        const response = await fetch('../../php/get_menu.php');
        const data = await response.json();
        
        if (data.success) {
            categoriesList = data.data;
            const categorySelect = document.getElementById('item-category');
            if (categorySelect) {
                categorySelect.innerHTML = '<option value="">Sélectionner</option>';
                categoriesList.forEach(cat => {
                    categorySelect.innerHTML += `<option value="${cat.category_id}">${cat.category_name}</option>`;
                });
            }
        }
    } catch (error) {
        console.error('Erreur:', error);
    }
}

// Charger le menu pour gestion
async function loadMenuForManagement() {
    const container = document.getElementById('menu-list');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Chargement...</div>';
    
    try {
        const response = await fetch('../../php/get_menu.php');
        const data = await response.json();
        
        if (data.success) {
            let html = '';
            data.data.forEach(category => {
                html += `
                    <div class="menu-category-card">
                        <div class="category-header">
                            <h3>${escapeHtml(category.category_name)}</h3>
                            <button class="btn-add" onclick="openAddMenuItemModalWithCategory(${category.category_id})">
                                <i class="fas fa-plus"></i> Ajouter
                            </button>
                        </div>
                        <div class="menu-items-list">
                `;
                
                if (category.items.length > 0) {
                    category.items.forEach(item => {
                        html += `
                            <div class="menu-item-row">
                                <div class="menu-item-info">
                                    <h4>${escapeHtml(item.name)}</h4>
                                    <p>${escapeHtml(item.description)}</p>
                                </div>
                                <div class="menu-item-price">${item.price} €</div>
                                <div class="menu-item-actions">
                                    <button class="btn-edit" onclick="editMenuItem(${item.id})">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button class="btn-delete" onclick="deleteMenuItem(${item.id})">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </div>
                        `;
                    });
                } else {
                    html += '<div class="loading" style="padding: 20px;">Aucun plat dans cette catégorie</div>';
                }
                
                html += '</div></div>';
            });
            
            container.innerHTML = html;
        }
    } catch (error) {
        container.innerHTML = '<div class="loading">Erreur de chargement du menu</div>';
    }
}

// Charger les messages
async function loadMessages() {
    const container = document.getElementById('messages-list');
    if (!container) return;
    
    container.innerHTML = '<div class="loading"><i class="fas fa-spinner fa-spin"></i> Chargement...</div>';
    
    try {
        const response = await fetch('php/get_messages.php');
        const data = await response.json();
        
        if (data.success && data.data.length > 0) {
            let html = `
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Nom</th>
                            <th>Email</th>
                            <th>Sujet</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
            `;
            
            data.data.forEach(msg => {
                html += `
                    <tr>
                        <td>${new Date(msg.created_at).toLocaleString('fr-FR')}</td>
                        <td>${escapeHtml(msg.name)}</td>
                        <td>${escapeHtml(msg.email)}</td>
                        <td>${escapeHtml(msg.subject || '-')}</td>
                        <td>${escapeHtml(msg.message)}</td>
                    </tr>
                `;
            });
            
            html += '</tbody></table>';
            container.innerHTML = html;
        } else {
            container.innerHTML = '<div class="loading">Aucun message</div>';
        }
    } catch (error) {
        container.innerHTML = '<div class="loading">Erreur de chargement</div>';
    }
}

// Charger les statistiques
async function loadStatistics() {
    try {
        const response = await fetch('php/get_stats.php');
        const data = await response.json();
        
        if (data.success) {
            const ctx = document.getElementById('stats-chart').getContext('2d');
            
            if (currentChart) {
                currentChart.destroy();
            }
            
            currentChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Réservations aujourd\'hui', 'Messages non lus', 'Plats au menu'],
                    datasets: [{
                        label: 'Nombre',
                        data: [
                            data.data.reservations_today,
                            data.data.unread_messages,
                            data.data.menu_items
                        ],
                        backgroundColor: '#e67e22',
                        borderRadius: 8
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        title: {
                            display: true,
                            text: 'Statistiques du restaurant'
                        }
                    }
                }
            });
            
            const detailedStats = `
                <div class="stats-grid">
                    <div class="stat-card">
                        <i class="fas fa-calendar-day"></i>
                        <div class="stat-info">
                            <h3>Réservations aujourd'hui</h3>
                            <p class="stat-number">${data.data.reservations_today}</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-hourglass-half"></i>
                        <div class="stat-info">
                            <h3>En attente</h3>
                            <p class="stat-number">${data.data.reservations_pending}</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-chart-line"></i>
                        <div class="stat-info">
                            <h3>Taux d'occupation moyen</h3>
                            <p class="stat-number">${data.data.occupancy_rate}%</p>
                        </div>
                    </div>
                    <div class="stat-card">
                        <i class="fas fa-euro-sign"></i>
                        <div class="stat-info">
                            <h3>CA estimé (mois)</h3>
                            <p class="stat-number">${data.data.estimated_revenue} €</p>
                        </div>
                    </div>
                </div>
            `;
            
            document.getElementById('detailed-stats').innerHTML = detailedStats;
        }
    } catch (error) {
        console.error('Erreur:', error);
    }
}

// Ouvrir modal pour ajouter un plat
function openAddMenuItemModal() {
    document.getElementById('modal-title').textContent = 'Ajouter un plat';
    document.getElementById('item-id').value = '';
    document.getElementById('item-name').value = '';
    document.getElementById('item-description').value = '';
    document.getElementById('item-price').value = '';
    document.getElementById('menu-modal').style.display = 'flex';
}

function openAddMenuItemModalWithCategory(categoryId) {
    openAddMenuItemModal();
    document.getElementById('item-category').value = categoryId;
}

// Modifier un plat
async function editMenuItem(id) {
    try {
        const response = await fetch('../../php/get_menu.php');
        const data = await response.json();
        
        let item = null;
        for (let cat of data.data) {
            const found = cat.items.find(i => i.id == id);
            if (found) {
                item = found;
                item.category_id = cat.category_id;
                break;
            }
        }
        
        if (item) {
            document.getElementById('modal-title').textContent = 'Modifier le plat';
            document.getElementById('item-id').value = item.id;
            document.getElementById('item-category').value = item.category_id;
            document.getElementById('item-name').value = item.name;
            document.getElementById('item-description').value = item.description;
            document.getElementById('item-price').value = item.price;
            document.getElementById('menu-modal').style.display = 'flex';
        }
    } catch (error) {
        showNotification('Erreur de chargement', 'error');
    }
}

// Supprimer un plat
async function deleteMenuItem(id) {
    if (confirm('Êtes-vous sûr de vouloir supprimer ce plat ?')) {
        try {
            const response = await fetch('php/delete_menu_item.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ id })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification('Plat supprimé', 'success');
                loadMenuForManagement();
                loadDashboardStats();
            } else {
                showNotification('Erreur lors de la suppression', 'error');
            }
        } catch (error) {
            showNotification('Erreur de connexion', 'error');
        }
    }
}

// Fermer modal
function closeMenuModal() {
    document.getElementById('menu-modal').style.display = 'none';
}

// Sauvegarder un plat
document.getElementById('menu-item-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const id = document.getElementById('item-id').value;
    const category_id = document.getElementById('item-category').value;
    const name = document.getElementById('item-name').value;
    const description = document.getElementById('item-description').value;
    const price = document.getElementById('item-price').value;
    
    if (!category_id || !name || !price) {
        showNotification('Veuillez remplir tous les champs obligatoires', 'error');
        return;
    }
    
    const url = id ? 'php/update_menu_item.php' : 'php/add_menu_item.php';
    const data = { category_id, name, description, price };
    if (id) data.id = id;
    
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification(id ? 'Plat modifié' : 'Plat ajouté', 'success');
            closeMenuModal();
            loadMenuForManagement();
            loadDashboardStats();
        } else {
            showNotification(result.message || 'Erreur', 'error');
        }
    } catch (error) {
        showNotification('Erreur de connexion', 'error');
    }
});

// Sauvegarder les paramètres
function saveSettings() {
    showNotification('Paramètres enregistrés', 'success');
}

// Notification
function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `<i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i> ${message}`;
    notification.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        background: ${type === 'success' ? '#28a745' : '#dc3545'};
        color: white;
        padding: 12px 20px;
        border-radius: 8px;
        z-index: 2000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

// Utilitaires
function getStatusText(status) {
    const statusMap = {
        'pending': 'En attente',
        'confirmed': 'Confirmée',
        'completed': 'Terminée',
        'cancelled': 'Annulée'
    };
    return statusMap[status] || status;
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}