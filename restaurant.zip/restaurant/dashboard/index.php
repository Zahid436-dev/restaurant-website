<?php
session_start();

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

$admin_name = $_SESSION['admin_name'];
$admin_role = $_SESSION['admin_role'];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - La Maison Bleue</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <!-- Sidebar -->
        <aside class="sidebar">
            <div class="sidebar-header">
                <i class="fas fa-utensils"></i>
                <h2>La Maison Bleue</h2>
                <p>Tableau de bord</p>
            </div>
            
            <nav class="sidebar-nav">
                <a href="#" class="nav-item active" data-page="dashboard">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Tableau de bord</span>
                </a>
                <a href="#" class="nav-item" data-page="reservations">
                    <i class="fas fa-calendar-check"></i>
                    <span>Réservations</span>
                    <span class="badge" id="pending-badge">0</span>
                </a>
                <a href="#" class="nav-item" data-page="menu">
                    <i class="fas fa-utensil-spoon"></i>
                    <span>Gestion du menu</span>
                </a>
                <a href="#" class="nav-item" data-page="messages">
                    <i class="fas fa-envelope"></i>
                    <span>Messages</span>
                    <span class="badge" id="messages-badge">0</span>
                </a>
                <a href="#" class="nav-item" data-page="stats">
                    <i class="fas fa-chart-line"></i>
                    <span>Statistiques</span>
                </a>
                <a href="#" class="nav-item" data-page="settings">
                    <i class="fas fa-cog"></i>
                    <span>Paramètres</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <div>
                        <p><?php echo htmlspecialchars($admin_name); ?></p>
                        <small><?php echo htmlspecialchars($admin_role); ?></small>
                    </div>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Déconnexion</span>
                </a>
            </div>
        </aside>
        
        <!-- Main Content -->
        <main class="main-content">
            <header class="main-header">
                <div class="header-title">
                    <h1 id="page-title">Tableau de bord</h1>
                    <p id="page-description">Bienvenue, <?php echo htmlspecialchars($admin_name); ?> !</p>
                </div>
                <div class="header-actions">
                    <div class="date-time" id="current-datetime"></div>
                </div>
            </header>
            
            <div class="content-area" id="content-area">
                <!-- Dashboard Home -->
                <div id="dashboard-page" class="page active">
                    <div class="stats-grid" id="stats-grid">
                        <div class="stat-card">
                            <i class="fas fa-calendar-day"></i>
                            <div class="stat-info">
                                <h3>Réservations aujourd'hui</h3>
                                <p class="stat-number" id="stat-today">-</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-clock"></i>
                            <div class="stat-info">
                                <h3>En attente</h3>
                                <p class="stat-number" id="stat-pending">-</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-envelope"></i>
                            <div class="stat-info">
                                <h3>Messages non lus</h3>
                                <p class="stat-number" id="stat-messages">-</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-chart-line"></i>
                            <div class="stat-info">
                                <h3>Taux d'occupation</h3>
                                <p class="stat-number" id="stat-occupancy">-</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-utensils"></i>
                            <div class="stat-info">
                                <h3>Plats au menu</h3>
                                <p class="stat-number" id="stat-menu">-</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <i class="fas fa-euro-sign"></i>
                            <div class="stat-info">
                                <h3>CA estimé (mois)</h3>
                                <p class="stat-number" id="stat-revenue">-</p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="recent-section">
                        <div class="section-header">
                            <h2>Réservations du jour</h2>
                            <button class="btn-refresh" onclick="loadTodayReservations()">
                                <i class="fas fa-sync-alt"></i> Actualiser
                            </button>
                        </div>
                        <div class="table-container" id="today-reservations">
                            <div class="loading">Chargement...</div>
                        </div>
                    </div>
                </div>
                
                <!-- Reservations Page -->
                <div id="reservations-page" class="page">
                    <div class="filters">
                        <input type="date" id="filter-date" class="filter-input">
                        <select id="filter-status" class="filter-input">
                            <option value="all">Tous les statuts</option>
                            <option value="pending">En attente</option>
                            <option value="confirmed">Confirmées</option>
                            <option value="completed">Terminées</option>
                            <option value="cancelled">Annulées</option>
                        </select>
                        <button class="btn-filter" onclick="loadReservations()">
                            <i class="fas fa-search"></i> Filtrer
                        </button>
                    </div>
                    <div class="table-container" id="reservations-list">
                        <div class="loading">Chargement...</div>
                    </div>
                </div>
                
                <!-- Menu Management Page -->
                <div id="menu-page" class="page">
                    <div class="section-header">
                        <h2>Gestion du menu</h2>
                        <button class="btn-add" onclick="openAddMenuItemModal()">
                            <i class="fas fa-plus"></i> Ajouter un plat
                        </button>
                    </div>
                    <div id="menu-list" class="menu-management">
                        <div class="loading">Chargement du menu...</div>
                    </div>
                </div>
                
                <!-- Messages Page -->
                <div id="messages-page" class="page">
                    <div class="section-header">
                        <h2>Messages des clients</h2>
                    </div>
                    <div class="table-container" id="messages-list">
                        <div class="loading">Chargement...</div>
                    </div>
                </div>
                
                <!-- Statistics Page -->
                <div id="stats-page" class="page">
                    <div class="section-header">
                        <h2>Statistiques détaillées</h2>
                    </div>
                    <canvas id="stats-chart" style="max-height: 400px; margin-bottom: 30px;"></canvas>
                    <div id="detailed-stats"></div>
                </div>
                
                <!-- Settings Page -->
                <div id="settings-page" class="page">
                    <div class="section-header">
                        <h2>Paramètres du restaurant</h2>
                    </div>
                    <div class="settings-form">
                        <div class="form-group">
                            <label>Nom du restaurant</label>
                            <input type="text" id="restaurant-name" value="La Maison Bleue" class="form-input">
                        </div>
                        <div class="form-group">
                            <label>Adresse</label>
                            <input type="text" id="restaurant-address" value="12 Rue des Gourmets, 75001 Paris" class="form-input">
                        </div>
                        <div class="form-group">
                            <label>Téléphone</label>
                            <input type="text" id="restaurant-phone" value="01 45 67 89 10" class="form-input">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" id="restaurant-email" value="contact@lamaisonbleue.fr" class="form-input">
                        </div>
                        <button class="btn-save" onclick="saveSettings()">Enregistrer les modifications</button>
                    </div>
                </div>
            </div>
        </main>
    </div>
    
    <!-- Modal pour ajouter/modifier un plat -->
    <div id="menu-modal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modal-title">Ajouter un plat</h3>
                <button class="close-modal" onclick="closeMenuModal()">&times;</button>
            </div>
            <form id="menu-item-form">
                <input type="hidden" id="item-id" value="">
                <div class="form-group">
                    <label>Catégorie</label>
                    <select id="item-category" required>
                        <option value="">Sélectionner</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Nom du plat</label>
                    <input type="text" id="item-name" required>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea id="item-description" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>Prix (€)</label>
                    <input type="number" id="item-price" step="0.01" required>
                </div>
                <div class="form-actions">
                    <button type="button" class="btn-cancel" onclick="closeMenuModal()">Annuler</button>
                    <button type="submit" class="btn-submit">Enregistrer</button>
                </div>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="js/dashboard.js"></script>
</body>
</html>