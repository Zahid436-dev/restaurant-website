<?php
session_start();
require_once '../../php/config.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

$conn = getConnection();

try {
    $stats = [];
    
    // Nombre de réservations aujourd'hui
    $today = date('Y-m-d');
    $query = "SELECT COUNT(*) as count FROM reservations WHERE date = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $today);
    $stmt->execute();
    $result = $stmt->get_result();
    $stats['reservations_today'] = $result->fetch_assoc()['count'];
    $stmt->close();
    
    // Nombre de réservations en attente
    $query = "SELECT COUNT(*) as count FROM reservations WHERE status = 'pending'";
    $result = $conn->query($query);
    $stats['reservations_pending'] = $result->fetch_assoc()['count'];
    
    // Nombre de messages non lus
    $query = "SELECT COUNT(*) as count FROM contact_messages WHERE is_read = 0";
    $result = $conn->query($query);
    $stats['unread_messages'] = $result->fetch_assoc()['count'];
    
    // Chiffre d'affaires du mois (estimation)
    $current_month = date('Y-m-01');
    $query = "SELECT SUM(price) as total FROM menu_items WHERE is_available = 1";
    $result = $conn->query($query);
    $stats['estimated_revenue'] = $result->fetch_assoc()['total'] * 15; // Estimation
    
    // Nombre de plats au menu
    $query = "SELECT COUNT(*) as count FROM menu_items WHERE is_available = 1";
    $result = $conn->query($query);
    $stats['menu_items'] = $result->fetch_assoc()['count'];
    
    // Taux d'occupation (exemple)
    $stats['occupancy_rate'] = rand(65, 95);
    
    echo json_encode(['success' => true, 'data' => $stats]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $conn->close();
}
?>