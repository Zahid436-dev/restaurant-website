<?php
session_start();
require_once '../../php/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

$conn = getConnection();

try {
    $query = "SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 50";
    $result = $conn->query($query);
    
    $messages = [];
    while ($row = $result->fetch_assoc()) {
        $messages[] = $row;
    }
    
    // Marquer comme lus
    $update_query = "UPDATE contact_messages SET is_read = 1 WHERE is_read = 0";
    $conn->query($update_query);
    
    echo json_encode(['success' => true, 'data' => $messages]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $conn->close();
}
?>