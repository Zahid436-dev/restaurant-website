<?php
session_start();
require_once '../../php/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../login.php?error=Méthode non autorisée');
    exit;
}

$username = isset($_POST['username']) ? trim($_POST['username']) : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

if (empty($username) || empty($password)) {
    header('Location: ../login.php?error=Veuillez remplir tous les champs');
    exit;
}

$conn = getConnection();

try {
    $query = "SELECT id, username, password, full_name, role FROM admin_users WHERE username = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        header('Location: ../login.php?error=Nom d\'utilisateur ou mot de passe incorrect');
        exit;
    }
    
    $user = $result->fetch_assoc();
    
    // Vérifier le mot de passe
    if (password_verify($password, $user['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_id'] = $user['id'];
        $_SESSION['admin_username'] = $user['username'];
        $_SESSION['admin_name'] = $user['full_name'];
        $_SESSION['admin_role'] = $user['role'];
        
        header('Location: ../index.php');
        exit;
    } else {
        header('Location: ../login.php?error=Nom d\'utilisateur ou mot de passe incorrect');
        exit;
    }
    
} catch (Exception $e) {
    header('Location: ../login.php?error=Erreur de connexion');
    exit;
} finally {
    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>