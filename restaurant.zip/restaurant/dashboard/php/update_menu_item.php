<?php
session_start();
require_once '../../php/config.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$item_id = isset($data['id']) ? intval($data['id']) : 0;
$category_id = isset($data['category_id']) ? intval($data['category_id']) : 0;
$name = isset($data['name']) ? trim($data['name']) : '';
$description = isset($data['description']) ? trim($data['description']) : '';
$price = isset($data['price']) ? floatval($data['price']) : 0;

if (!$item_id || !$category_id || !$name || $price <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Données invalides']);
    exit;
}

$conn = getConnection();

try {
    // Vérifier si le plat existe
    $check_query = "SELECT id FROM menu_items WHERE id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("i", $item_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Plat non trouvé']);
        exit;
    }
    $check_stmt->close();
    
    // Mettre à jour le plat
    $query = "UPDATE menu_items SET category_id = ?, name = ?, description = ?, price = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("issdi", $category_id, $name, $description, $price, $item_id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Plat mis à jour avec succès',
            'id' => $item_id
        ]);
    } else {
        throw new Exception("Erreur lors de la mise à jour");
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>