<?php
session_start();
require_once '../../php/config.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$reservation_id = isset($data['id']) ? intval($data['id']) : 0;

if (!$reservation_id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ID de réservation invalide']);
    exit;
}

$conn = getConnection();

try {
    // Vérifier si la réservation existe
    $check_query = "SELECT id, name, date, time FROM reservations WHERE id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("i", $reservation_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Réservation non trouvée']);
        exit;
    }
    
    $reservation = $check_result->fetch_assoc();
    $check_stmt->close();
    
    // Supprimer la réservation
    $query = "DELETE FROM reservations WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $reservation_id);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true, 
            'message' => 'Réservation supprimée avec succès',
            'deleted_reservation' => [
                'name' => $reservation['name'],
                'date' => $reservation['date'],
                'time' => $reservation['time']
            ]
        ]);
    } else {
        throw new Exception("Erreur lors de la suppression");
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    if (isset($stmt)) $stmt->close();
    $conn->close();
}
?>