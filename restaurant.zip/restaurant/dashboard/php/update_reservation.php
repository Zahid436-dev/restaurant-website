<?php
session_start();
require_once '../../php/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$reservation_id = isset($data['id']) ? intval($data['id']) : 0;
$status = isset($data['status']) ? $data['status'] : '';

if (!$reservation_id || !$status) {
    echo json_encode(['success' => false, 'message' => 'Données invalides']);
    exit;
}

$conn = getConnection();

try {
    $query = "UPDATE reservations SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("si", $status, $reservation_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Statut mis à jour']);
    } else {
        throw new Exception("Erreur lors de la mise à jour");
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $stmt->close();
    $conn->close();
}
?>