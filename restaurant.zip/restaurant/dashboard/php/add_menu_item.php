<?php
session_start();
require_once '../../php/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Méthode non autorisée']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$category_id = isset($data['category_id']) ? intval($data['category_id']) : 0;
$name = isset($data['name']) ? trim($data['name']) : '';
$description = isset($data['description']) ? trim($data['description']) : '';
$price = isset($data['price']) ? floatval($data['price']) : 0;

if (!$category_id || !$name || $price <= 0) {
    echo json_encode(['success' => false, 'message' => 'Données invalides']);
    exit;
}

$conn = getConnection();

try {
    $query = "INSERT INTO menu_items (category_id, name, description, price, is_available) VALUES (?, ?, ?, ?, 1)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("issd", $category_id, $name, $description, $price);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Plat ajouté avec succès', 'id' => $stmt->insert_id]);
    } else {
        throw new Exception("Erreur lors de l'ajout");
    }
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $stmt->close();
    $conn->close();
}
?>