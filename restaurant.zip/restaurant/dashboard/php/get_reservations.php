<?php
session_start();
require_once '../../php/config.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Non autorisé']);
    exit;
}

$conn = getConnection();

try {
    $date_filter = isset($_GET['date']) ? $_GET['date'] : date('Y-m-d');
    $status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
    
    $query = "SELECT * FROM reservations WHERE date = ?";
    $params = [$date_filter];
    $types = "s";
    
    if ($status_filter !== 'all') {
        $query .= " AND status = ?";
        $params[] = $status_filter;
        $types .= "s";
    }
    
    $query .= " ORDER BY time ASC";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $reservations = [];
    while ($row = $result->fetch_assoc()) {
        $reservations[] = $row;
    }
    
    echo json_encode(['success' => true, 'data' => $reservations]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
} finally {
    $conn->close();
}
?>