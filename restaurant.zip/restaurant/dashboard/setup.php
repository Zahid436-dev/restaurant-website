<?php
// Activer l'affichage des erreurs pour le débogage
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Définir le chemin absolu vers config.php
$config_path = __DIR__ . '/../php/config.php';

// Vérifier si le fichier config.php existe
if (!file_exists($config_path)) {
    die("❌ Erreur: Le fichier config.php n'existe pas à l'emplacement: " . $config_path);
}

require_once $config_path;

echo "<h1>Installation du Dashboard</h1>";

// Vérifier la connexion à la base de données
try {
    $conn = getConnection();
    echo "✅ Connexion à la base de données réussie<br>";
} catch (Exception $e) {
    die("❌ Erreur de connexion: " . $e->getMessage());
}

// 1. Créer la table admin_users si elle n'existe pas
echo "<h2>1. Vérification de la table admin_users</h2>";

$create_table = "
CREATE TABLE IF NOT EXISTS admin_users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role ENUM('admin', 'manager', 'staff') DEFAULT 'manager',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($create_table)) {
    echo "✅ Table admin_users créée ou déjà existante<br>";
} else {
    echo "❌ Erreur création table: " . $conn->error . "<br>";
}

// 2. Vérifier si la colonne password a la bonne longueur
echo "<h2>2. Vérification de la structure de la table</h2>";

$check_column = $conn->query("SHOW COLUMNS FROM admin_users WHERE Field = 'password'");
if ($check_column && $check_column->num_rows > 0) {
    $column_info = $check_column->fetch_assoc();
    if (strpos($column_info['Type'], 'varchar') !== false) {
        echo "✅ La colonne password est bien de type VARCHAR<br>";
    } else {
        echo "⚠️ La colonne password n'est pas de type VARCHAR: " . $column_info['Type'] . "<br>";
        // Modifier la colonne
        $conn->query("ALTER TABLE admin_users MODIFY password VARCHAR(255) NOT NULL");
        echo "✅ Colonne password modifiée en VARCHAR(255)<br>";
    }
}

// 3. Générer le hash pour 'chef123'
echo "<h2>3. Création de l'utilisateur chef</h2>";

$password = 'chef123';
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

echo "Mot de passe: " . $password . "<br>";
echo "Hash généré: " . $hashed_password . "<br><br>";

// Supprimer l'ancien utilisateur s'il existe
$conn->query("DELETE FROM admin_users WHERE username = 'chef'");

// Insérer le nouvel utilisateur
$query = "INSERT INTO admin_users (username, password, full_name, role) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("❌ Erreur de préparation: " . $conn->error);
}

$username = 'chef';
$full_name = 'Chef du Restaurant';
$role = 'admin';

$stmt->bind_param("ssss", $username, $hashed_password, $full_name, $role);

if ($stmt->execute()) {
    echo "✅ Utilisateur créé avec succès !<br><br>";
    echo "<div style='background: #d4edda; padding: 15px; border-radius: 8px; margin: 10px 0;'>";
    echo "<strong>🔑 Identifiants de connexion:</strong><br>";
    echo "📧 Utilisateur: <strong style='color: #155724;'>chef</strong><br>";
    echo "🔒 Mot de passe: <strong style='color: #155724;'>chef123</strong><br>";
    echo "</div>";
} else {
    echo "❌ Erreur lors de l'insertion: " . $stmt->error . "<br>";
}

$stmt->close();

// 4. Vérifier que l'utilisateur a bien été créé
echo "<h2>4. Vérification de l'utilisateur dans la base</h2>";

$check_query = "SELECT * FROM admin_users WHERE username = 'chef'";
$result = $conn->query($check_query);

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    echo "✅ Utilisateur trouvé dans la base:<br>";
    echo "<ul>";
    echo "<li>ID: " . $user['id'] . "</li>";
    echo "<li>Username: " . $user['username'] . "</li>";
    echo "<li>Full name: " . $user['full_name'] . "</li>";
    echo "<li>Role: " . $user['role'] . "</li>";
    echo "<li>Password hash: " . substr($user['password'], 0, 30) . "...</li>";
    echo "</ul>";
    
    // Tester la vérification du mot de passe
    if (password_verify($password, $user['password'])) {
        echo "✅ Test de vérification: Le mot de passe 'chef123' est valide!<br>";
        echo "✅ Vous pouvez maintenant vous connecter au dashboard.<br>";
    } else {
        echo "❌ Test de vérification: Le mot de passe ne correspond pas au hash!<br>";
    }
} else {
    echo "❌ Utilisateur non trouvé dans la base après insertion!<br>";
}

// 5. Afficher tous les utilisateurs existants
echo "<h2>5. Liste des utilisateurs existants</h2>";
$all_users = $conn->query("SELECT id, username, full_name, role FROM admin_users");
if ($all_users && $all_users->num_rows > 0) {
    echo "<table border='1' cellpadding='8' cellspacing='0' style='border-collapse: collapse;'>";
    echo "<tr><th>ID</th><th>Username</th><th>Nom complet</th><th>Rôle</th></tr>";
    while ($user = $all_users->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $user['id'] . "</td>";
        echo "<td>" . $user['username'] . "</td>";
        echo "<td>" . $user['full_name'] . "</td>";
        echo "<td>" . $user['role'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "Aucun utilisateur trouvé dans la table.<br>";
}

// 6. Lien vers la page de connexion
echo "<h2>6. Accéder au dashboard</h2>";
echo "<a href='login.php' style='display: inline-block; background: #e67e22; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; margin-top: 10px;'>Aller à la page de connexion</a>";

$conn->close();
?>